from django.shortcuts import render, get_object_or_404, redirect
from .models import Producto, Categoria
from .forms import ProductoForm


def producto_lista(request):
    productos = Producto.objects.select_related('categoria').all()
    categorias = Categoria.objects.all()
    
    cat_id = request.GET.get('categoria')
    if cat_id:
        productos = productos.filter(categoria_id=cat_id)

    contexto = {
        'productos': productos,
        'categorias': categorias,
        'categoria_seleccionada': cat_id,
    }
    return render(request, 'catalogo/lista.html', contexto)


def producto_detalle(request, pk):
    producto = get_object_or_404(Producto, pk=pk)
    contexto = {'producto': producto}
    return render(request, 'catalogo/detalle.html', contexto)



def producto_crear(request):
    if request.method == 'POST':
        form = ProductoForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('producto_lista')
    else:
        form = ProductoForm()
    
    return render(request, 'catalogo/form_producto.html', {'form': form})